CREATE FUNCTION CheckRoomInCinema(
  @CinemaName VARCHAR(MAX)
)
 RETURNS INT AS
  BEGIN
    DECLARE @RoomCount INT
    SELECT @RoomCount = RoomsQuantity FROM Cinema WHERE @CinemaName = CinemaName
    RETURN @RoomCount;
  END
go


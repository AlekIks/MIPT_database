;


CREATE TRIGGER dbo.PlaceCheck
   ON  Place
   AFTER INSERT, UPDATE
AS
   IF UPDATE(PlaceNumber)
      BEGIN
        DECLARE @PlaceNumber INT;
        SELECT @PlaceNumber = PlaceNumber FROM inserted

        DECLARE @CinemaName VARCHAR(MAX)
        SELECT @CinemaName = CinemaName FROM inserted

        DECLARE @PlacesQuantity INT;
        SELECT @PlacesQuantity = PLacesQuantity FROM Room
                WHERE @CinemaName = Room.CinemaName

        IF (@PlaceNumber > @PlacesQuantity OR @PlaceNumber <= 0)
          BEGIN
              ROLLBACK TRANSACTION;
             RAISERROR ('Некорректный номер места.', 16, 1);
          END
      END

-- --------------------------------------------------------
-- CHECK ROOMS IN CINEMA

DROP TRIGGER dbo.RoomNumberInCinemaCheck
go


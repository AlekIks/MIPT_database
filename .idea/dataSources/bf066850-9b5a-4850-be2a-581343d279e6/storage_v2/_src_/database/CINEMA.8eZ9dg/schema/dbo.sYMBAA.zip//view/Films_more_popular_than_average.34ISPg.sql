CREATE VIEW [Films more popular than average] AS
SELECT FilmName, FilmRating
  FROM Film
  WHERE FilmRating > (SELECT AVG(FilmRating) FROM Film)
go

-- No source code for CINEMA.dbo.Films more popular than average.UpdateViewTrigger
go


;


CREATE PROCEDURE dbo.UpdateView (
  @FilmName VARCHAR(MAX),
  @Rating INT
)
  AS BEGIN
  UPDATE [Films more popular than average]
    SET FilmRating = @Rating
    WHERE FilmName = @FilmName
end
go


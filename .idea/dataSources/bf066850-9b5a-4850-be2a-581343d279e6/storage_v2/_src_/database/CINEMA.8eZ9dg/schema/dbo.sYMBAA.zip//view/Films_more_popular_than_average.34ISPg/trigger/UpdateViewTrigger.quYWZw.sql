;


CREATE TRIGGER dbo.UpdateViewTrigger
  ON [Films more popular than average]
  INSTEAD OF UPDATE
  AS IF UPDATE(FilmRating)
    BEGIN

      DECLARE @FilmName VARCHAR(MAX)
      DECLARE @FilmRating INT
      SELECT @FilmName = FilmName, @FilmRating = FilmRating FROM inserted

      UPDATE Film SET Film.FilmRating = @FilmRating
      WHERE FilmName = @FilmName
    END
go

